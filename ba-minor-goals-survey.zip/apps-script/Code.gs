/**
 * Google Apps Script backend for the Business Analytics learning goals survey.
 * It saves each submission as a row in the Google Sheet it is attached to,
 * and returns all responses (as JSON) to the results page.
 *
 * Setup: see README.md, "Step 3".
 */

// Change this to any password you like. The results page asks for it,
// so only people who know it can view the responses.
const RESULTS_KEY = "change-me";

const SHEET_NAME = "Responses";
const GOAL_IDS = ["G01","G02","G03","G04","G05","G06","G07","G08","G09","G10","G11","G12","G13","G14","G15"];
const HEADERS = ["Timestamp", "Name", "Comments"].concat(GOAL_IDS);

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
  }
  return sh;
}

// Receives a submission from the survey page
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const data = JSON.parse(e.postData.contents);
    const ratings = data.ratings || {};
    const row = [new Date(), clean_(data.name, 100), clean_(data.comments, 2000)];
    GOAL_IDS.forEach(function (id) {
      const v = Number(ratings[id]);
      row.push(v >= 1 && v <= 5 ? v : "");
    });
    getSheet_().appendRow(row);
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

// Returns all responses to the results page (requires the key)
function doGet(e) {
  if (!e || !e.parameter || e.parameter.key !== RESULTS_KEY) {
    return json_({ ok: false, error: "Wrong or missing key" });
  }
  const values = getSheet_().getDataRange().getValues();
  const header = values.shift();
  const rows = values.map(function (r) {
    const o = {};
    header.forEach(function (h, i) {
      o[h] = r[i] instanceof Date ? r[i].toISOString() : r[i];
    });
    return o;
  });
  return json_({ ok: true, rows: rows });
}

function clean_(s, max) {
  s = String(s || "").slice(0, max);
  // Stop spreadsheet formula injection
  return /^[=+\-@]/.test(s) ? "'" + s : s;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
